import { useQuery } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { InitialState, ListHarga } from '../App';

import Separator from './ui/separator';
import loading from '../assets/throbber_small.svg';
import crIcon from '../assets/cr-icon.svg';

async function getData() {
  const { data } = await fetch(
    'https://script.googleusercontent.com/macros/echo?user_content_key=qu6wgWdH7QSFmtwGsXj-z7_NA3ZQUagXlaUMRZjp-WpcoT5rjZOeqqxZ-dvUpxXT4C1GyQop4ZmL7qO_xZagxBhFRwuDXFpJm5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnCxUlnzbBtqifodrZ0dHFF88urT39WIpG3VSl7gWVtiQ69W5pXi3J7XXOQTaSanNtteUgrhUSHbUkQJWB9tbC1hSTAVBngA2ONz9Jw9Md8uu&lib=MqrGu7_NK7DgzNd7NCg7Df9-SEuHcTGPa'
  ).then((res) => res.json());

  return data;
}

interface Props {
  harga: InitialState;
  setHarga: React.Dispatch<React.SetStateAction<InitialState>>;
}

const ceckUpdate = (x: ListHarga, y: ListHarga) => {
  let hargaAtasLocal;
  let hargaBawahLocal;
  if (x) {
    // hargaAtasLocal = x[0][1];
    // hargaBawahLocal = x[0][2];
  }
  // const hargaAtasServer = y[0][1];
  // const hargaBawahServer = y[0][1];

  // return (
  //   hargaAtasLocal !== hargaAtasServer || hargaBawahLocal !== hargaBawahServer
  // );
};

export default function Update({ harga, setHarga }: Props) {
  const { isPending, error, data, refetch } = useQuery({
    queryKey: ['get-list-harga'],
    queryFn: getData,
    enabled: false,
  });

  const [update, setUpdate] = useState(false);

  useEffect(() => {
    setHarga({ ...harga, listHarga: data });
  }, [data]);

  if (!data && !update)
    return (
      <div>
        <button
          onClick={() => {
            refetch();
            setUpdate(!update);
          }}
          className="text-blue-500 border-b border-blue-500"
        >
          Update harga
        </button>
      </div>
    );

  if (isPending)
    return (
      <div className="flex gap-x-4">
        <img src={loading} alt="throbber small" height={24} width={24} />
        <p>Sedang update harga</p>
      </div>
    );

  if (error)
    return (
      <div className="flex gap-x-2">
        <p>Gagal update harga,</p>
        <button
          onClick={() => refetch()}
          className="text-blue-500 border-b border-blue-500"
        >
          Coba lagi
        </button>
      </div>
    );

  // return (
  //   <div className="flex items-center gap-x-4">
  //     {ceckUpdate(harga.listHarga, data) ? (
  //       <>
  //         <p>Harga sudah terupdate</p>
  //         <Separator height="h-8" />
  //         <button
  //           onClick={() => location.reload()}
  //           className="border border-blue-500 text-blue-500 py-2 px-6 rounded-3xl font-light"
  //         >
  //           Reload
  //         </button>
  //       </>
  //     ) : (
  //       <>
  //         <img src={crIcon} alt="cr-icon" width={24} height={24} />
  //         <p>Harga sudah up to date</p>
  //       </>
  //     )}
  //   </div>
  // );
}
