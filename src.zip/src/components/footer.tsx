import Separator from './ui/separator';
import { InitialState } from '../App';
import { formatToK } from '../lib/utils';

interface Props {
  harga: InitialState;
}

export default function Footer({ harga }: Props) {
  let { ppn, extra, listHarga } = harga;

  let hargaAtas;
  let hargaBawah;

  if (listHarga && listHarga[0]) {
    hargaAtas = listHarga[0][1];
    hargaBawah = listHarga[0][2];
  } else {
    hargaAtas = '-';
    hargaBawah = '-';
  }

  ppn = Number(ppn) > 0 ? ppn : '-';
  extra = Number(extra) > 0 ? formatToK(Number(extra)) : '-';

  return (
    <footer>
      <div className="flex items-center text-xs text-gray-400 font-mono">
        <div>{hargaAtas}</div>
        <Separator />
        <div>{hargaBawah}</div>
        <Separator />
        <div>{ppn}</div>
        <Separator />
        <div>{extra}</div>
        <div className="font-sans ml-4">&copy; {new Date().getFullYear()}</div>
      </div>
    </footer>
  );
}
