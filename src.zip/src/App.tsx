import { useEffect, useState } from 'react';

import FormMain from './components/form-main';
import Footer from './components/footer';
import tripleDot from './assets/triple-dot.svg';
import Header from './components/header';
import { hitungHarga } from './lib/utils';
import Update from './components/update';

export interface ListHarga {
  pen: string;
  kadar: number;
  harga: number;
}

export interface InitialState {
  hpr: string;
  berat: string;
  ppn?: string;
  extra?: string;
  listHarga: ListHarga[];
}

/*
=======================
  APP
=======================
*/
function App() {
  const [harga, setHarga] = useState<InitialState>({
    hpr: '',
    berat: '',
    ppn: '',
    extra: '',
    listHarga: [],
  });

  const totalHarga = hitungHarga({ ...harga });

  return (
    <main className="max-w-prose mx-auto p-8 flex flex-col min-h-svh [&>:last-child]:mt-auto gap-y-8">
      <div>
        <button
          onClick={() => ''}
          className="hover:bg-slate-100 inline-block p-2 rounded-full"
        >
          <img
            className="pointer-events-none"
            src={tripleDot}
            alt="button setting"
            width={24}
          />
        </button>
      </div>

      <Header totalHarga={totalHarga} />
      <FormMain harga={harga} setHarga={setHarga} />

      <Update harga={harga} setHarga={setHarga} />

      <Footer harga={harga} />
    </main>
  );
}

export default App;
